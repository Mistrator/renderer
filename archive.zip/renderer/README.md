# Renderer

CS-C2120 (Ohjelmointistudio 2) course project: a real-time software 3D renderer.