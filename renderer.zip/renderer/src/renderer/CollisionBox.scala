package renderer

class CollisionBox(val bottomLeftCorner: Vector4, val topRightCorner: Vector4)
